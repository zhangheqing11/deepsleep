"""被测系统层（会谈 agent / playbook / 反思器 / 门禁 / 版本库）。

归属：王译旋。见 AGENTS.md §6。
"""
